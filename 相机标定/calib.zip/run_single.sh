chmod +x ./build/opencv_single_calib
./build/opencv_single_calib ./data/calibration.yml
