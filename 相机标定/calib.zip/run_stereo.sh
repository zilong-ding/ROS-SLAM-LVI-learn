chmod +x ./build/opencv_stereo_calib
cd data
../build/opencv_stereo_calib ./stereo_calib.xml
