//#include "cameraModel/caliberator.h"
#include "opencv2/core.hpp" //核心的部分
#include "opencv2/calib3d.hpp" //相机标定与三维重建
#include "opencv2/imgproc.hpp"//图像处理
#include "opencv2/highgui.hpp"//窗口显示
#include "opencv2/imgcodecs.hpp"//图像编码部分

#include <iostream>
#include <vector>
#include <string>

using namespace std;
using namespace cv;

int main(int argc, char** argv)
{
	vector<string> vPaths;
	std::vector<std::vector<cv::Point2f>> image_points_seq; /* 保存检测到的所有角点 */
	std::vector<std::vector<cv::Point3f>> object_points; /* 保存标定板上角点的三维坐标 */
	for (int i = 0; i < 5; i++)
	{
		vPaths.push_back("../data/calib/left0" + to_string(i + 1) + ".jpg");
	}

	std::cout << "Start find corners..." << endl;
	for (int i = 0; i < 5; i++)
	{
		//单个图像即可标定！
		std::cout << "Now is processing " << i + 1 << " image." << endl;
		cv::Mat cb_source = cv::imread(vPaths[i]);
		std::vector<cv::Point2f> image_points; //保存单个图像的角点

		if (cv::findChessboardCorners(cb_source, cv::Size(6, 9), image_points, 0) == 0)
		{
			cout << "didn't find corners!" << endl;
			return 0;
		}
		else
		{
			cv::Mat img;
			//（2）转为灰度图像
			cvtColor(cb_source, img, cv::COLOR_RGB2GRAY); //???

			//（3）对提取的粗角点进行精细化处理，这里的用法是
			/*
			bool find4QuadCornerSubpix(InputArray img, //输入图像
									InputOutputArray corners, //输出的角点
									Size region_size ); //搜索区域大小
			*/
			cv::find4QuadCornerSubpix(img, image_points, cv::Size(5, 5));

			//(4)亚像素检测角点，这里的用法是
			/*
			void cornerSubPix(InputArray image,
							InputOutputArray corners,
							Size winSize,搜索窗口半径，如果winSize=Size(5,5),则search windows为11*11
							Size zeroZone,（-1，-1)
							TermCriteria criteria //控制迭代次数与精度
							);
			*/
			cv::cornerSubPix(img, image_points, cv::Size(5, 5), cv::Size(-1, -1),
				cv::TermCriteria(cv::TermCriteria::COUNT + cv::TermCriteria::EPS, 30, DBL_EPSILON)); //???

//(5)绘制检测到的角点
			cv::Mat cb_corner = cb_source.clone();
			cv::drawChessboardCorners(cb_corner, cv::Size(6, 9), image_points, true);
			cv::imwrite("../data/res/res" + to_string(i) + ".jpg", cb_corner);

			//(6)给到总的序列里面去
			image_points_seq.push_back(image_points);

			std::cout << "Start calibrating ..." << endl;

			cv::Size square_size = cv::Size(1, 1); //标定板实际对应的是多少
			cv::Mat cameraMatrix = cv::Mat(3, 3, CV_32FC1, cv::Scalar::all(0)); /* 摄像机内参数矩阵 */
			cv::Mat distCoeffs = cv::Mat(1, 5, CV_32FC1, cv::Scalar::all(0)); /* 摄像机的5个畸变系数：k1,k2,p1,p2,k3 */
			std::vector<cv::Mat> tvecsMat;  /* 每幅图像的旋转向量 */
			std::vector<cv::Mat> rvecsMat;  /* 每幅图像的平移向量 */

			//（1）计算标定板中的角点在世界坐标系下的坐标
			// 实际上这里就要求，标定板是不动的
			std::vector<cv::Point3f> realPoint;
			for (int i = 0; i < 6; i++) {
				for (int j = 0; j < 9; j++) {
					cv::Point3f tempPoint;
					/* 假设标定板放在世界坐标系中z=0的平面上 */
					tempPoint.x = i * square_size.width;
					tempPoint.y = j * square_size.height;
					tempPoint.z = 0;
					realPoint.push_back(tempPoint);
				}
			}
			object_points.push_back(realPoint);

			printf("#image_points： %ld\n", sizeof(image_points_seq[0]));
			std::cout << image_points << std::endl;

			//（7）执行标定，此处的用法是
			/*
			double calibrateCamera(InputArrayOfArrays objectPoints, //角点的世界坐标系
								InputArrayOfArrays imagePoints, //角点的图像坐标系
								Size imageSize,//图像大小
								InputOutputArray cameraMatrix,//图像内参数矩阵3✖3
								InputOutputArray distCoeffs,//图像畸变系数矩阵1✖5
								OutputArrayOfArrays rvecs,//旋转向量
								OutputArrayOfArrays tvecs,//平移向量
								int flags = 0,
								TermCriteria criteria = TermCriteria(
								TermCriteria::COUNT + TermCriteria::EPS, 30, DBL_EPSILON) );

			*/
			cv::calibrateCamera(object_points, image_points_seq, cv::Size(640, 480),
				cameraMatrix, distCoeffs, rvecsMat, tvecsMat,
				cv::CALIB_USE_LU);

			std::cout << "tvecsMat:\n" << tvecsMat[0] << std::endl;
			std::cout << "rvecsMat:\n" << rvecsMat[0] << std::endl;

			std::cout << "#cameraMatrix:\n" << cameraMatrix << std::endl;
			std::cout << "#distCoeffs:\n" << distCoeffs << std::endl;

			//对图像进行校正
			cv::Mat cb_final;
			cv::Mat mapx = cv::Mat(cb_source.size(), CV_32FC1);
			cv::Mat mapy = cv::Mat(cb_source.size(), CV_32FC1);
			cv::Mat R = cv::Mat::eye(3, 3, CV_32F);
			//initUndistortRectifyMap(cameraMatrix, distCoeffs, R, cv::Mat(), cb_source.size(), CV_32FC1,
			//                        mapx, mapy);
			//cv::remap(cb_source, cb_final, mapx, mapy, cv::INTER_LINEAR);

			cv::undistort(cb_source, cb_final, cameraMatrix, distCoeffs);
			cv::imwrite("../data/res/res_final" + to_string(i) + ".jpg", cb_final);
		}
	}
	return 0;
}